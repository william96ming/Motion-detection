/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2021 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "stdio.h"
#include "watch_test.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
/** Configuration array generated from Unico Tool **/
const ucf_line_t watch_test[] = {
  {.address = 0x10, .data = 0x00,},
  {.address = 0x11, .data = 0x00,},
  {.address = 0x01, .data = 0x80,},
  {.address = 0x04, .data = 0x00,},
  {.address = 0x05, .data = 0x00,},
  {.address = 0x5F, .data = 0x4B,},
  {.address = 0x46, .data = 0x07,},
  {.address = 0x47, .data = 0x00,},
  {.address = 0x0A, .data = 0x81,},
  {.address = 0x0B, .data = 0x07,},
  {.address = 0x0C, .data = 0x00,},
  {.address = 0x0E, .data = 0x80,},
  {.address = 0x0F, .data = 0x00,},
  {.address = 0x10, .data = 0x00,},
  {.address = 0x17, .data = 0x40,},
  {.address = 0x09, .data = 0x00,},
  {.address = 0x02, .data = 0x11,},
  {.address = 0x08, .data = 0x7A,},
  {.address = 0x09, .data = 0x00,},
  {.address = 0x09, .data = 0x00,},
  {.address = 0x09, .data = 0x03,},
  {.address = 0x09, .data = 0x03,},
  {.address = 0x09, .data = 0x00,},
  {.address = 0x09, .data = 0x04,},
  {.address = 0x02, .data = 0x41,},
  {.address = 0x08, .data = 0x00,},
  {.address = 0x09, .data = 0xA2,},
  {.address = 0x09, .data = 0x00,},
  {.address = 0x09, .data = 0x18,},
  {.address = 0x09, .data = 0x00,},
  {.address = 0x09, .data = 0x11,},
  {.address = 0x09, .data = 0x00,},
  {.address = 0x09, .data = 0x9A,},
  {.address = 0x09, .data = 0x39,},
  {.address = 0x09, .data = 0x00,},
  {.address = 0x09, .data = 0x44,},
  {.address = 0x09, .data = 0xA8,},
  {.address = 0x09, .data = 0x00,},
  {.address = 0x09, .data = 0x02,},
  {.address = 0x09, .data = 0x00,},
  {.address = 0x09, .data = 0x00,},
  {.address = 0x09, .data = 0x06,},
  {.address = 0x09, .data = 0x2E,},
  {.address = 0x09, .data = 0x12,},
  {.address = 0x09, .data = 0x66,},
  {.address = 0x09, .data = 0x53,},
  {.address = 0x09, .data = 0x77,},
  {.address = 0x09, .data = 0x46,},
  {.address = 0x09, .data = 0x22,},
  {.address = 0x09, .data = 0x00,},
  {.address = 0x09, .data = 0xBA,},
  {.address = 0x09, .data = 0x20,},
  {.address = 0x09, .data = 0x30,},
  {.address = 0x09, .data = 0x00,},
  {.address = 0x09, .data = 0x22,},
  {.address = 0x09, .data = 0x00,},
  {.address = 0x09, .data = 0x00,},
  {.address = 0x09, .data = 0x38,},
  {.address = 0x09, .data = 0x66,},
  {.address = 0x09, .data = 0x2E,},
  {.address = 0x09, .data = 0xCC,},
  {.address = 0x09, .data = 0x00,},
  {.address = 0x09, .data = 0x00,},
  {.address = 0x09, .data = 0x00,},
  {.address = 0x09, .data = 0x20,},
  {.address = 0x09, .data = 0x00,},
  {.address = 0x09, .data = 0xEC,},
  {.address = 0x09, .data = 0x28,},
  {.address = 0x09, .data = 0x00,},
  {.address = 0x09, .data = 0x00,},
  {.address = 0x09, .data = 0x00,},
  {.address = 0x09, .data = 0x00,},
  {.address = 0x09, .data = 0x00,},
  {.address = 0x09, .data = 0x00,},
  {.address = 0x09, .data = 0x00,},
  {.address = 0x09, .data = 0x00,},
  {.address = 0x09, .data = 0x00,},
  {.address = 0x09, .data = 0x00,},
  {.address = 0x09, .data = 0x02,},
  {.address = 0x09, .data = 0x00,},
  {.address = 0x09, .data = 0x68,},
  {.address = 0x09, .data = 0x00,},
  {.address = 0x09, .data = 0x0A,},
  {.address = 0x09, .data = 0x03,},
  {.address = 0x09, .data = 0x12,},
  {.address = 0x09, .data = 0x23,},
  {.address = 0x09, .data = 0x01,},
  {.address = 0x09, .data = 0x66,},
  {.address = 0x09, .data = 0x16,},
  {.address = 0x09, .data = 0x23,},
  {.address = 0x09, .data = 0x07,},
  {.address = 0x09, .data = 0x25,},
  {.address = 0x09, .data = 0x23,},
  {.address = 0x09, .data = 0x00,},
  {.address = 0x09, .data = 0x03,},
  {.address = 0x09, .data = 0x88,},
  {.address = 0x09, .data = 0x54,},
  {.address = 0x09, .data = 0x22,},
  {.address = 0x09, .data = 0x54,},
  {.address = 0x09, .data = 0x00,},
  {.address = 0x09, .data = 0x14,},
  {.address = 0x09, .data = 0x00,},
  {.address = 0x09, .data = 0x0E,},
  {.address = 0x09, .data = 0x00,},
  {.address = 0x09, .data = 0xCD,},
  {.address = 0x09, .data = 0x34,},
  {.address = 0x09, .data = 0xA8,},
  {.address = 0x09, .data = 0x00,},
  {.address = 0x09, .data = 0x00,},
  {.address = 0x09, .data = 0x00,},
  {.address = 0x09, .data = 0x70,},
  {.address = 0x09, .data = 0x00,},
  {.address = 0x09, .data = 0x23,},
  {.address = 0x09, .data = 0x01,},
  {.address = 0x09, .data = 0x66,},
  {.address = 0x09, .data = 0x51,},
  {.address = 0x09, .data = 0x22,},
  {.address = 0x09, .data = 0x00,},
  {.address = 0x04, .data = 0x00,},
  {.address = 0x05, .data = 0x01,},
  {.address = 0x17, .data = 0x00,},
  {.address = 0x01, .data = 0x00,},
  {.address = 0x01, .data = 0x00,},
  {.address = 0x02, .data = 0x3F,},
  {.address = 0x07, .data = 0x20,},
  {.address = 0x08, .data = 0x80,},
  {.address = 0x09, .data = 0x06,},
  {.address = 0x0A, .data = 0x00,},
  {.address = 0x0B, .data = 0x00,},
  {.address = 0x0C, .data = 0x00,},
  {.address = 0x0D, .data = 0x00,},
  {.address = 0x0E, .data = 0x00,},
  {.address = 0x10, .data = 0x68,},
  {.address = 0x11, .data = 0x60,},
  {.address = 0x12, .data = 0x04,},
  {.address = 0x13, .data = 0x00,},
  {.address = 0x14, .data = 0x00,},
  {.address = 0x15, .data = 0x00,},
  {.address = 0x16, .data = 0x00,},
  {.address = 0x17, .data = 0x00,},
  {.address = 0x18, .data = 0xE0,},
  {.address = 0x19, .data = 0x00,},
  {.address = 0x56, .data = 0x00,},
  {.address = 0x57, .data = 0x00,},
  {.address = 0x58, .data = 0x00,},
  {.address = 0x59, .data = 0x00,},
  {.address = 0x5A, .data = 0x00,},
  {.address = 0x5B, .data = 0x00,},
  {.address = 0x5C, .data = 0x00,},
  {.address = 0x5D, .data = 0x00,},
  {.address = 0x5E, .data = 0x02,},
  {.address = 0x5F, .data = 0x02,},
  {.address = 0x73, .data = 0x00,},
  {.address = 0x74, .data = 0x00,},
  {.address = 0x75, .data = 0x00,}
};


/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
  
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
I2C_HandleTypeDef hi2c1;

TIM_HandleTypeDef htim1;
TIM_HandleTypeDef htim2;
TIM_HandleTypeDef htim3;
TIM_HandleTypeDef htim4;

/* USER CODE BEGIN PV */

static const uint8_t ism330_ADDR = 0xD6; //salver device address
const uint8_t start_FLASH = 0x86;
const uint8_t stop_FLASH = 0x00;
const uint8_t read_acce = 0x03;
const uint8_t read_gyro = 0x30;
int BT2_stop = 1;
uint32_t flash_ADDR = 0x08010000;                     //flash writing start at
int INT_flag = 0;

  //initials LED
  int time_2 = 0;
  int time_3 = 0;
  int cur_time = 0;
  int LED_2_flag = 0;
  int LED_3_flag = 0;

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_TIM4_Init(void);
static void MX_I2C1_Init(void);
static void MX_TIM3_Init(void);
static void MX_TIM1_Init(void);
static void MX_TIM2_Init(void);
/* USER CODE BEGIN PFP */



/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/**
  *@brief Read sensor data from FIFO, and write data to flash memeroy
  */
static void Write_data_to_FLASH(void){
  
  int num_of_words;
  uint8_t pData;
  
    HAL_I2C_Mem_Read(&hi2c1,ism330_ADDR,0x3B,1,&pData,1,50);
    num_of_words = ((pData | 0x03) << 8);
    HAL_I2C_Mem_Read(&hi2c1,ism330_ADDR,0x3A,1,&pData,1,50);
    num_of_words = num_of_words | pData;
      
      if(num_of_words > 0)
      {             //if there is data in FIFO
        // writing data into flash, each data takes 8 bytes <= 1 byte(constant 0) + 1 byte (tag) + 6 bytes (fixed number)
        HAL_FLASH_Program(FLASH_TYPEPROGRAM_BYTE,flash_ADDR,0);           //write 0 in the first byte (out of 8 bytes)
        flash_ADDR += 1;
        
        for(int j=0x78;j <= 0x7E;j++){          //tag store in ADDR 0x78, fixed number store in ADDR 0x79 - 0x7E
        HAL_I2C_Mem_Read(&hi2c1,ism330_ADDR,j,1,&pData,1,50);           //read from FIFO
        asm("nop");
        HAL_FLASH_Program(FLASH_TYPEPROGRAM_BYTE,flash_ADDR,pData);     //write into flash
        flash_ADDR += 1;
        }
      }
  
}

/**
  *@brief Start/Stop data recording process status by Bottom 2
  *@param acce_or_gyro selector to control FIFO(access data from accelemeter or gyroscope)
  */
static void Bottom2_control(int acce_or_gyro){
  
    if(BT2_stop == 1){                
        //start recording data if pervious status is stop
        BT2_stop = 0;          //change the flag
        HAL_GPIO_WritePin(LED2_GPIO_Port, LED1_Pin, GPIO_PIN_RESET);            //TURN ON LED 1
        
        //Set FIFO read data from accelemeter or gyroscope
        if(acce_or_gyro == 1)           
          HAL_I2C_Mem_Write(&hi2c1, ism330_ADDR, 0x09, 1, (uint8_t *)&read_acce, 1, 50);
        else if(acce_or_gyro == 0)
          HAL_I2C_Mem_Write(&hi2c1, ism330_ADDR, 0x09, 1, (uint8_t *)&read_gyro, 1, 50);
        
        //setupt FIFO to continous mode
        HAL_I2C_Mem_Write(&hi2c1, ism330_ADDR, 0x0A, 1, (uint8_t *)&start_FLASH, 1, 50);        
        
        }else if(BT2_stop == 0){               
          //stop recording data if pervious status is start
          BT2_stop = 1;          //change the flag
          HAL_GPIO_WritePin(LED2_GPIO_Port, LED1_Pin, GPIO_PIN_SET);            //TURN OFF LED 1
          
          //set FIFO to bypass mode(disabled)
          HAL_I2C_Mem_Write(&hi2c1, ism330_ADDR, 0x0A, 1, (uint8_t *)&stop_FLASH, 1, 50);         
          
          //write some "0"  in flash after stopping to seperate data
          for(int k = 1; k <= 16 ; k ++){
            HAL_FLASH_Program(FLASH_TYPEPROGRAM_BYTE,flash_ADDR,0); 
            flash_ADDR += 1;
          }
        }
}

/**
  *@brief turn on LEDx 
  *@param LEDx_Pin
  */
static void LED_ON(int LEDx_Pin){
  
  if(LEDx_Pin == LED2_Pin | LEDx_Pin == LED3_Pin)
  HAL_GPIO_WritePin(LED2_GPIO_Port, LEDx_Pin, GPIO_PIN_RESET);            //TURN ON LEDx
  
}

/**
  *@brief turn off LEDx
  *@param LEDx_Pin
  */
static void LED_OFF(int LEDx_Pin){
  
  if((LEDx_Pin == LED2_Pin & (cur_time - time_2) > 1000) | (LEDx_Pin == LED3_Pin & (cur_time - time_3) > 1000))
  HAL_GPIO_WritePin(LED2_GPIO_Port, LEDx_Pin, GPIO_PIN_SET);            //TURN OFF LEDx
  
}

/**
  *@brief configure FSM in sensor by writing the data into sensor memory
  */
static void write_FSM(void){
  
    unsigned int size = sizeof(watch_test)/sizeof(ucf_line_t);           //find the size of FSM program
      //****writing FSM to sensor (I2C channel) ****//
    HAL_I2C_Mem_Write(&hi2c1, ism330_ADDR, watch_test[0].address, 1, (uint8_t *)&watch_test[0].data, 1, 50);
    HAL_Delay(100);             //delay after the first write (needed)
    for(int i=1;i<=size;i++)
    {
    HAL_I2C_Mem_Write(&hi2c1, ism330_ADDR, watch_test[i].address, 1, (uint8_t *)&watch_test[i].data, 1, 50);
    asm("nop");
    }
}

/**
  *@brief configuration before control the sensor & earse the flash memory of MCU
  */
static void initial_configuration(void){
  
  //****start PWM (configure the power supply of sensor)****//
  HAL_TIM_PWM_Start(&htim3,TIM_CHANNEL_1);
  HAL_TIM_PWM_Start(&htim3,TIM_CHANNEL_2);
  HAL_TIM_PWM_Start(&htim3,TIM_CHANNEL_3);
  htim3.Instance->CCR1 = 50; //50% duty cycle
  htim3.Instance->CCR2 = 50; //50% duty cycle
  htim3.Instance->CCR3 = 50; //50% duty cycle
  
   //**** enable CTR_EN pin ****//
   HAL_GPIO_WritePin(CTR_EN_GPIO_Port, CTR_EN_Pin, GPIO_PIN_RESET);
   
   //****unlock Flash****//
   HAL_FLASH_Unlock();
    
   //****initials for flash erase****//
   uint32_t Error;
   FLASH_EraseInitTypeDef test;
   test.TypeErase = FLASH_TYPEERASE_SECTORS;
   test.Sector = FLASH_SECTOR_4;         //start from sector 4(0x0810000)
   test.NbSectors = 4;
   test.VoltageRange = FLASH_VOLTAGE_RANGE_3;            //2.7V to 3.6V
   //****Earse the flash for data writing****//
   HAL_FLASHEx_Erase(&test, &Error);
  
}
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */
  
  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_TIM4_Init();
  MX_I2C1_Init();
  MX_TIM3_Init();
  MX_TIM1_Init();
  MX_TIM2_Init();
  /* USER CODE BEGIN 2 */
  
  initial_configuration();
  
  write_FSM();

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
    
    /*if LOOP for interrupt flag*/
    if(INT_flag == 1){
      Bottom2_control(1);               //read data from accelemeter
      //Bottom2_control(0);             //read data from gyposcope
    }
    else if(INT_flag == 2){
      LED_ON(LED2_Pin);
      LED_2_flag = 1;
      time_2 =__HAL_TIM_GetCounter(&htim4);
    }
    else if(INT_flag == 3){
      LED_ON(LED3_Pin);
      LED_3_flag = 1;
      time_3 = __HAL_TIM_GetCounter(&htim4);
    }
    
    if(LED_2_flag == 1)
      LED_OFF(LED2_Pin);
    if(LED_3_flag == 1)
      LED_OFF(LED3_Pin);
    
    INT_flag = 0;       //clear interrupt flag
    
    
    /*Flash writing controled by Bottom 2*/
    if(BT2_stop == 0)
     Write_data_to_FLASH();
    
    if(BT2_stop == 1)
      HAL_I2C_Mem_Write(&hi2c1, ism330_ADDR, 0x0A, 1, (uint8_t *)&stop_FLASH, 1, 50);
    
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE2);
  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_HSI;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief I2C1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2C1_Init(void)
{

  /* USER CODE BEGIN I2C1_Init 0 */

  /* USER CODE END I2C1_Init 0 */

  /* USER CODE BEGIN I2C1_Init 1 */

  /* USER CODE END I2C1_Init 1 */
  hi2c1.Instance = I2C1;
  hi2c1.Init.ClockSpeed = 100000;
  hi2c1.Init.DutyCycle = I2C_DUTYCYCLE_2;
  hi2c1.Init.OwnAddress1 = 0;
  hi2c1.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c1.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c1.Init.OwnAddress2 = 0;
  hi2c1.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c1.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN I2C1_Init 2 */

  /* USER CODE END I2C1_Init 2 */

}

/**
  * @brief TIM1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM1_Init(void)
{

  /* USER CODE BEGIN TIM1_Init 0 */

  /* USER CODE END TIM1_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM1_Init 1 */

  /* USER CODE END TIM1_Init 1 */
  htim1.Instance = TIM1;
  htim1.Init.Prescaler = 0;
  htim1.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim1.Init.Period = 65535;
  htim1.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim1.Init.RepetitionCounter = 0;
  htim1.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim1) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim1, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim1, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM1_Init 2 */

  /* USER CODE END TIM1_Init 2 */

}

/**
  * @brief TIM2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM2_Init(void)
{

  /* USER CODE BEGIN TIM2_Init 0 */

  /* USER CODE END TIM2_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM2_Init 1 */

  /* USER CODE END TIM2_Init 1 */
  htim2.Instance = TIM2;
  htim2.Init.Prescaler = 0;
  htim2.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim2.Init.Period = 4294967295;
  htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim2) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim2, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim2, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM2_Init 2 */

  /* USER CODE END TIM2_Init 2 */

}

/**
  * @brief TIM3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM3_Init(void)
{

  /* USER CODE BEGIN TIM3_Init 0 */

  /* USER CODE END TIM3_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};

  /* USER CODE BEGIN TIM3_Init 1 */

  /* USER CODE END TIM3_Init 1 */
  htim3.Instance = TIM3;
  htim3.Init.Prescaler = 7;
  htim3.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim3.Init.Period = 99;
  htim3.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim3.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_ENABLE;
  if (HAL_TIM_Base_Init(&htim3) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim3, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_Init(&htim3) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim3, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 0;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  if (HAL_TIM_PWM_ConfigChannel(&htim3, &sConfigOC, TIM_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_ConfigChannel(&htim3, &sConfigOC, TIM_CHANNEL_2) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_ConfigChannel(&htim3, &sConfigOC, TIM_CHANNEL_3) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM3_Init 2 */

  /* USER CODE END TIM3_Init 2 */
  HAL_TIM_MspPostInit(&htim3);

}

/**
  * @brief TIM4 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM4_Init(void)
{

  /* USER CODE BEGIN TIM4_Init 0 */

  /* USER CODE END TIM4_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM4_Init 1 */

  /* USER CODE END TIM4_Init 1 */
  htim4.Instance = TIM4;
  htim4.Init.Prescaler = 16000;
  htim4.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim4.Init.Period = 999;
  htim4.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim4.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim4) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim4, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim4, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM4_Init 2 */

  /* USER CODE END TIM4_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOE_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(DIR_INT3_INT4_GPIO_Port, DIR_INT3_INT4_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOE, LED2_Pin|LED3_Pin|LED1_Pin, GPIO_PIN_SET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOD, CTR_EN_Pin|CTR_EN_I2C_SDI_Pin, GPIO_PIN_SET);

  /*Configure GPIO pin : DIR_INT3_INT4_Pin */
  GPIO_InitStruct.Pin = DIR_INT3_INT4_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(DIR_INT3_INT4_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : LED2_Pin LED3_Pin LED1_Pin */
  GPIO_InitStruct.Pin = LED2_Pin|LED3_Pin|LED1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOE, &GPIO_InitStruct);

  /*Configure GPIO pins : Flash_w_sign_Pin INTI_2_Pin INTI_1_Pin */
  GPIO_InitStruct.Pin = Flash_w_sign_Pin|INTI_2_Pin|INTI_1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pins : CTR_EN_Pin CTR_EN_I2C_SDI_Pin */
  GPIO_InitStruct.Pin = CTR_EN_Pin|CTR_EN_I2C_SDI_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);

  /* EXTI interrupt init*/
  HAL_NVIC_SetPriority(EXTI9_5_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(EXTI9_5_IRQn);

  HAL_NVIC_SetPriority(EXTI15_10_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(EXTI15_10_IRQn);

}

/* USER CODE BEGIN 4 */

/**
  *@brief GPIO interrupt callback function
  *@param GPIO_Pin
*/
void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)          
{  
   if(GPIO_Pin == GPIO_PIN_10) // Bottom_2
   {    
      INT_flag = 1;
      
   }else if(GPIO_Pin == GPIO_PIN_8)                //Interrupt_1
   {
     INT_flag = 2;
          
   }else if(GPIO_Pin == GPIO_PIN_5)                //Interrupt_2
   {
     INT_flag = 3;
        
   }else{
     INT_flag = 0;              //default
   }

}


/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
